This code is developed as a team and stored for future reference
