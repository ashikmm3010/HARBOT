def config():
    config = {     
      "apiKey": "API_KEY",
      "authDomain": "fir-DOMAIN-default-rtdb",
      "databaseURL": "https://fir-DOMAIN-default-rtdb.firebaseio.com/",
      "storageBucket": "HARBOT"
    }
    return config
